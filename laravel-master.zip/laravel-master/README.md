# laravel
### When the project is clone
### First time run
    composer update
    composer install
    php artisan key:generate
* Note: In case .env does not exist, rename .env.example to .env
### Database Configuration
    HOST=18.143.106.141
    Port=3306
    Db=ContactDB
    User=root
    Pass=Rupp2357.!
