<tr>
    <td colspan="6">
        <p class="alert alert-danger">There is no record</p>
    </td>
</tr>
<?php /**PATH /Users/vangvannakka/Downloads/Gather/RUPP ITE/S2 Y3/WCT2/laravel-master/resources/views/contacts/_empty.blade.php ENDPATH**/ ?>