<select class="form-select">
    <option value="" selected>All Companies</option>
    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value=<?php echo e($key); ?>><?php echo e($company->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH /Users/vangvannakka/Downloads/Gather/RUPP ITE/S2 Y3/WCT2/laravel-master/resources/views/contacts/_company.blade.php ENDPATH**/ ?>