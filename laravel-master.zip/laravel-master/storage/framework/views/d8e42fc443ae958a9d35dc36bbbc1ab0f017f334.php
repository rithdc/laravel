<tr <?php if($loop->even): ?> class="table-primary" <?php endif; ?>>
    <th scope="row"><?php echo e($loop->index); ?></th>
    <td><?php echo e($contact->first_name); ?></td>
    <td><?php echo e($contact->last_name); ?></td>
    <td><?php echo e($contact->email); ?></td>
    <td><?php echo e($contact->company_id); ?></td>
    <td width="150">
    <a href="<?php echo e(route('contacts.show',$contact->id)); ?>" class="btn btn-sm btn-circle btn-outline-info" title="Show"><i class="bi bi-eye-fill"></i></a>
    <a href="<?php echo e(route('contacts.create')); ?>" class="btn btn-sm btn-circle btn-outline-secondary" title="Edit"><i class="bi bi-pencil-square"></i></a>
<a href="#" class="btn btn-sm btn-circle btn-outline-danger" title="Delete" onclick="confirm('Are you sure?')"><i class="bi bi-x-circle"></i></a></td>
</tr>
<?php /**PATH /Users/vangvannakka/Downloads/Gather/RUPP ITE/S2 Y3/WCT2/laravel-master/resources/views/contacts/_contact.blade.php ENDPATH**/ ?>