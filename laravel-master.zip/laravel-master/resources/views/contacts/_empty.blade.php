<tr>
    <td colspan="6">
        <p class="alert alert-danger">There is no record</p>
    </td>
</tr>
